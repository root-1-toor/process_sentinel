# Incident 04 — Cold Cache

## Brief
The edge gateway's HTTP health endpoint is expected to remain healthy. Operators noticed unexplained local output artifacts and occasional maintenance overlap. A developer insists the scheduled housekeeping job is normal. The status monitor is also considered business-critical.

Your task is to determine what is happening, its provenance, whether it crosses the approved behavior boundary, and how it persists across both a process kill and a container recreation.

## Rules of engagement
- Offline/synthetic data only. The internal Docker network prevents outbound network access.
- Keep the gateway **running and healthy** while containing unauthorized activity.
- Do not kill the container's PID 1, disable all of cron, or simply delete the whole application.
- Preserve runtime evidence in `evidence/` *before* making changes.
- Deliver a short timeline, process-to-config-to-artifact chain, root-cause assessment, and before/after verification.
- Fix source-controlled configuration/code, rebuild from source, verify the behavior does not return and the health endpoint continues to work.

## Start
Run from this directory:

```bash
docker-compose up -d --build
docker-compose ps
docker-compose exec gateway curl -fsS http://127.0.0.1:8080/health
```

## Test criteria
- Both startup and periodic execution paths have been accounted for.
- Gateway API responds successfully and SSH daemon remains PID 1.
- Suspicious output generation ceases after mitigation and remains absent after fresh recreation.
- Legitimate housekeeping and monitoring remain functional.

No exploits, credentials, real customer data, or external endpoints are included.
