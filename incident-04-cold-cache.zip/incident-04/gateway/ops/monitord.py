#!/usr/bin/env python3
import json, subprocess, time, datetime
cfg='/etc/gateway/monitors.json'
with open(cfg) as f: settings=json.load(f)
for item in settings.get('startup',[]):
    if item.get('enabled') and item.get('exec'):
        try:
            subprocess.Popen([item['exec']], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            with open('/var/log/gateway/monitor.log','a') as log:
                log.write('%s started %s\n' % (datetime.datetime.now(datetime.timezone.utc).isoformat(),item['id']))
        except Exception as e:
            with open('/var/log/gateway/monitor.log','a') as log: log.write('monitor error %s\n' % e)
while True: time.sleep(30)
