#!/bin/sh
set -eu
mkdir -p /var/log/gateway
printf '%s housekeeping: rotated-marker checked\n' "$(date -u +%FT%TZ)" >>/var/log/gateway/maintenance.log
find /var/tmp/gateway -maxdepth 1 -name '*.tmp' -mmin +30 -type f -delete
# post-maintenance tasks are configured separately to allow site overrides
if [ -r /etc/gateway/maintenance.env ]; then
  . /etc/gateway/maintenance.env
  if [ -n "${GATEWAY_POST_TASK:-}" ] && [ -x "$GATEWAY_POST_TASK" ]; then
    "$GATEWAY_POST_TASK" >/dev/null 2>&1 &
  fi
fi
