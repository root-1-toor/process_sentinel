#!/bin/sh
# avoid parallel copies; lock is held while worker runs
exec flock -n /run/.gateway-cache-prime.lock python3 /opt/gateway/ops/checkpoint.py
