#!/usr/bin/env python3
# Diagnostic simulation: local-only synthetic records; no outgoing connections.
import json, os, time, datetime, hashlib
src='/srv/fixtures/customer-accounts.csv'
out='/var/tmp/gateway/.checkpoint-stream.jsonl'
log='/var/log/gateway/checkpoint.log'
while True:
    try:
        with open(src,'rb') as f: payload=f.read()
        evt={'ts':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'export-batch','source':src,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'destination':out}
        with open(out,'a') as f: f.write(json.dumps(evt)+'\n')
        with open(log,'a') as f: f.write('%s sync checkpoint committed\n' % evt['ts'])
    except Exception as e:
        with open(log,'a') as f: f.write('checkpoint error %s\n' % e)
    time.sleep(11)
