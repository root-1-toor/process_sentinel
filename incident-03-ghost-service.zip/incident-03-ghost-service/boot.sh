#!/bin/sh
set -e
cron
exec /usr/sbin/sshd -D -e
