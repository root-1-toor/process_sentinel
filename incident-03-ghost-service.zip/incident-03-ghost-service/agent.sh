#!/bin/sh
while true; do
  dd if=/dev/zero of=/dev/null bs=1024 count=512 2>/dev/null
  sleep 8
done
