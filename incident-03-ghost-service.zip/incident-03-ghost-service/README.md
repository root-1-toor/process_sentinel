# Incident 03 — The Ghost Service

**Mission:** Determine why a background process returns, identify the control point, preserve evidence, and eliminate the recurring job without losing SSH gateway availability.

## Deploy

```bash
docker-compose up -d --build
docker-compose ps
docker-compose exec -T gateway ps -eo pid,ppid,user,stat,etime,args --forest
```

## Investigation focus

Observe cron-created `gateway-agent` instances. Inspect Linux signal effects using only PIDs confirmed to belong to this disposable container. Understand `SIGSTOP` (suspend), `SIGCONT` (resume), `SIGTERM` (termination request), and Docker container PID 1. Avoid indiscriminately killing the host's `sshd`, `dockerd`, or `containerd`.

## Recorded outcome

The analyst experimented with `SIGSTOP` on worker and cron-child processes, then later clarified that they had sent `SIGTERM` through `htop`. The gateway's SSH daemon logged `Received signal 15; terminating.` and the container exited with code 0. Docker's event stream showed a `die` event. This established signal and lifecycle behavior; **permanent removal of the cron mechanism was not demonstrated**.

This lab was originally called “advanced” but, in retrospective evaluation, was easier than Incident 02 because the recurring cron lineage was immediately visible.

## Safety

The workload writes no external data and the network is isolated. Use this only as a disposable incident-response simulation.
