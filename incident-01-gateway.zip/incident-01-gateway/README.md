# Incident 01 — Gateway

**Mission:** Investigate suspicious SSH authentication, identify `operator`, examine restricted sudo usage, identify background activity, and contain test-account access.

## Launch

```bash
docker-compose up -d --build
docker-compose exec -T probe /scenario/run-scenario.sh
```

## Investigation entry points

```bash
docker-compose exec -T target cat /var/log/sshd.log
docker-compose exec -T target cat /var/log/sudo.log
docker-compose exec -T target ps -eo pid,ppid,user,stat,args --forest
docker-compose exec -T target sudo -l -U operator
```

**Expected analysis:** Differentiate failed and successful SSH authentication; understand that permission to run `/usr/bin/id` as root is **not** full sudo administration; correlate processes with owner and environment. For containment inside this disposable lab, inspect the test account and lock its password with `passwd -l operator` in the target, then attempt another password login from the probe.

## Recorded investigation

The original logs show investigation of host/container PID mismatches and `operator` shell loops of the form `while true; do sleep 600 & wait $!; sleep 2; done`, with experiments using `ps`, `pstree`, `lsof`, and signals. The complete original verification of account lockdown is **not** established by the retained evidence. Treat this as a reproducible teaching scenario, not a certified closed incident.

## Safety/provenance

The target Dockerfile and entrypoint were recovered from observed source output. The **probe run-scenario.sh is reconstructed** and may produce a different number of SSH attempts than the original. All credentials are synthetic, fixed lab-only credentials. Keep this lab isolated and never expose port 22.
