#!/bin/sh
# Reconstructed lab-only client script (original source unavailable).
set -eu
host=target
opts='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o PreferredAuthentications=password -o PubkeyAuthentication=no -o NumberOfPasswordPrompts=1 -o ConnectTimeout=5'
for pass in wrong-one wrong-two wrong-three; do
  # Intentional failed authentication events.
  sshpass -p "$pass" ssh $opts operator@"$host" id >/dev/null 2>&1 || true
done
sshpass -p lab-access-only ssh $opts operator@"$host" 'id; hostname; sudo /usr/bin/id' || true
printf 'Scenario activity complete.\n'
