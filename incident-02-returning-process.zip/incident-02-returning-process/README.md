# Incident 02 — The Returning Process

**Mission:** Examine why `.system-metrics`, running as `operator`, continually reappears. Identify its execution mechanism and demonstrate live containment without bringing down the SSH gateway.

## Deploy

```bash
docker-compose up -d --build
docker-compose exec -T probe /scenario/run-scenario.sh
docker-compose exec -T target ps -eo pid,ppid,user,etime,args --forest
```

## Expected investigation

Investigate process lineage from inside the container and from the Linux host; distinguish PID namespaces. Watch instances accumulate over several minutes. Find launch sources and capture `evidence/` snapshots before changes. This intentionally simple sleep workload is **not malware**.

## Recorded outcome

The investigation found a startup-launched process and a minute-by-minute cron entry. `pkill -f .system-metrics` removed shells but the workload returned. The user then removed `/etc/cron.d/system-metrics` and `/usr/local/bin/.system-metrics` inside the live container, terminated `operator` processes, and verified that only `sshd` and `cron` remained. This was **live containment**, not source-level remediation. A clean rebuild from the provided unmodified sources reintroduces the simulation.

A separate Docker lifecycle experiment ended with the probe reporting `Exit=137`, `OOM=false`, while the target continued running.

## Security notes

The original simulation intentionally includes a test account/password. All behavior is internal to Docker; do not publish SSH ports or deploy this image beyond an isolated lab.
