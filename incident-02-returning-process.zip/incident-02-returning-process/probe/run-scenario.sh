#!/bin/sh
# Harmless simulated SSH authentication activity.
set -eu
opts='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o PreferredAuthentications=password -o PubkeyAuthentication=no -o NumberOfPasswordPrompts=1 -o ConnectTimeout=5'
for pass in bad-one bad-two; do
  sshpass -p "$pass" ssh $opts operator@target id >/dev/null 2>&1 || true
done
sshpass -p lab-access-only ssh $opts operator@target 'id; hostname' || true
printf 'Scenario activity complete.\n'
